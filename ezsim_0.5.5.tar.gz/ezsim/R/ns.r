#' @import foreach ggplot2 parallel digest reshape 
NULL

#' @importFrom Jmisc addCol evalFunctionOnList label_both_parsed_recode recode
NULL

#' @importFrom plyr ddply dlply summarize
NULL